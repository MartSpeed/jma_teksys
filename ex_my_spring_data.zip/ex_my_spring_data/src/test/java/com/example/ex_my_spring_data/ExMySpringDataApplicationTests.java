package com.example.ex_my_spring_data;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExMySpringDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
