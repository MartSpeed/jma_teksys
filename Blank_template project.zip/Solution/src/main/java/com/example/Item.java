package com.example;

public class Item{
    
    
    public Item() {
        // Your code here
    }
    
    public Item(String itemName, String itemDesc, Double itemPrice, Integer availableQuantity) {
        // Your code here
    }
    
    
    
}
