package com.example.jma_thymeleaftour;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JmaThymeleafTourApplication {

	public static void main(String[] args) {
		SpringApplication.run(JmaThymeleafTourApplication.class, args);
	}

}
