package com.example.jma_thymeleaftour;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JmaThymeleafTourApplicationTests {

	@Test
	void contextLoads() {
	}

}
