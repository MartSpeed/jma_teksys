package com.example.ex_springsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExSpringsecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExSpringsecurityApplication.class, args);
	}

}
