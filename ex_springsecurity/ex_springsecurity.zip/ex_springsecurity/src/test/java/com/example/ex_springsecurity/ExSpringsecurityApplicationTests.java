package com.example.ex_springsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExSpringsecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
