package com.example.Anthony_John_Order_Parts_CaseStudy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnthonyJohnOrderPartsCaseStudyApplicationTests {

	@Test
	void contextLoads() {
	}

}
