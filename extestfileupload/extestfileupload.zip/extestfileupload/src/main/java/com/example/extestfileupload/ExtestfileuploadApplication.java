package com.example.extestfileupload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExtestfileuploadApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExtestfileuploadApplication.class, args);
	}

}
