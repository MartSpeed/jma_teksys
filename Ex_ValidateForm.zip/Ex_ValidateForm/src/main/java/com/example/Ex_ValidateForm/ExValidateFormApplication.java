package com.example.Ex_ValidateForm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExValidateFormApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExValidateFormApplication.class, args);
	}

}
