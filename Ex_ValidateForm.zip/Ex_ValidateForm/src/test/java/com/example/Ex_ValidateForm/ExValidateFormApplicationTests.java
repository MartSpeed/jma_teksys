package com.example.Ex_ValidateForm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExValidateFormApplicationTests {

	@Test
	void contextLoads() {
	}

}
