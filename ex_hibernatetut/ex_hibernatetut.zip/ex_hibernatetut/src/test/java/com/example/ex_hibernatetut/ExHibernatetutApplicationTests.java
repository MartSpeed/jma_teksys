package com.example.ex_hibernatetut;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExHibernatetutApplicationTests {

	@Test
	void contextLoads() {
	}

}
