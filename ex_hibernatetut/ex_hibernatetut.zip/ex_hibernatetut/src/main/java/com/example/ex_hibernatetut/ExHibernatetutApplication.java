package com.example.ex_hibernatetut;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExHibernatetutApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExHibernatetutApplication.class, args);
	}

}
