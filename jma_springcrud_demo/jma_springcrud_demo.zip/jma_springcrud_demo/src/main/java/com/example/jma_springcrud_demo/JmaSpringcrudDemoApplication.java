package com.example.jma_springcrud_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JmaSpringcrudDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JmaSpringcrudDemoApplication.class, args);
	}

}
