package com.example.jma_springcrud_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JmaSpringcrudDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
