package com.example.jma_EmployeeManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JmaEmployeeManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(JmaEmployeeManagerApplication.class, args);
	}

}
