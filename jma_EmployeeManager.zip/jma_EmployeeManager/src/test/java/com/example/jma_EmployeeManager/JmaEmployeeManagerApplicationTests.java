package com.example.jma_EmployeeManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JmaEmployeeManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
