package com.example.ex_studentapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExStudentappApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExStudentappApplication.class, args);
	}

}
