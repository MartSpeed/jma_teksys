package com.example.jma_my_spring_data;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JmaMySpringDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
