package com.example.jma_my_spring_data;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JmaMySpringDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(JmaMySpringDataApplication.class, args);
	}

}
