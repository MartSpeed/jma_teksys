package com.example;

import java.util.HashMap;

public class CartSystem extends TheSystem {
	private double subTotal, total;
	private static final double TAX = 0.05;

	CartSystem() {
	}

	@Override
	public void display() {
		System.out.println("Cart: ");
		HashMap<String, Item> disItem = getItemCollection();
		subTotal = 0;
		System.out.printf("%-20s %-20s %-10s %-10s %-10s%n", "Name", "Description", "Price", "Quantity", "Sub Total");

		disItem.entrySet().forEach(entry -> {
			Item valItem = entry.getValue();
			double subTotal = valItem.getItemPrice() * valItem.getQuantity();
			subTotal += subTotal;
			System.out.printf("%-20s %-20s %-10.2f %-10d %-10.2f %n", valItem.getItemName(), valItem.getItemDesc(),
					valItem.getItemPrice(), valItem.getQuantity(), subTotal);
		});
		double preTax = subTotal * TAX;
		total = preTax + subTotal;
		System.out.printf("%-20s %-20.2f%n%-20s %-20.2f%n%-20s %-20.2f%n", "Pre-Tax Total", subTotal, "Tax", preTax,
				"Total", total);
	}
}
