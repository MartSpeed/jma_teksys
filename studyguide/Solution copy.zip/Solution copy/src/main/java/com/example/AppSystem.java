package com.example;

import java.util.HashMap;

public class AppSystem extends TheSystem {
	AppSystem() {
	}

	@Override
	public void display() {
		System.out.println("AppSystem Iventory:");
		HashMap<String, Item> items = getItemCollection();
		System.out.printf("%-20s %-20s %-10.2f %-10d%n", "Name", "Description", "Price", "Available Quantity");

		items.entrySet().forEach(entry -> {
			Item disItem = entry.getValue();
			System.out.printf("%-20s %-20s %-10.2f %-10d%n", disItem.getItemName(), disItem.getItemDesc(),
					disItem.getItemPrice(), disItem.getAvailableQuantity());

		});
	}

	@Override // this overwrites the parents class add method
	public Boolean add(Item item) {
		if (item != null) {
			if (getItemCollection().containsKey(item.getItemName())) {
				System.out.println(item.getItemName() + " is already in the App System.");
				return false;
			}else {
				getItemCollection().put(item.getItemName(), item);
				return true;
			}
		} else {
			return false;
		}
	}

	public Item reduceAvailableQuantity(String item_name) {
		if (getItemCollection().containsKey(item_name)) {
			Item colItem = getItemCollection().get(item_name);
			colItem.setAvailableQuantity(colItem.getAvailableQuantity() - 1);
			if (colItem.getAvailableQuantity() <= 0) {
				getItemCollection().remove(item_name);
				return colItem;
			}
			getItemCollection().replace(item_name, colItem);
			return colItem;
		} else { 
			return null;
		}
	}
}
