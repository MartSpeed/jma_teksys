package com.example;

public class Item {
	// fields
	private String itemName, itemDesc;
	private Double itemPrice;
	private Integer quantity, availableQuantity;

	public Item() {
		// set the initialize quantity
		this.quantity = 1;
	}

	public Item(String itemName, String itemDesc, Double itemPrice, Integer quantity, Integer availableQuantity) {
		// Your code here
		this.itemName = itemName;
		this.itemDesc = itemDesc;
		this.itemPrice = itemPrice;
		this.quantity = quantity;
		this.availableQuantity = availableQuantity;
	}

	// getters/setters
	// ***STRING GETTERS/SETTERS START***
	// itemName
	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	// itemDesc
	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}
	// ***STRING GETTERS/SETTERS START***

	// ***DOUBLE GETTERS START***
	// itemPrice
	public Double getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(Double itemPrice) {
		this.itemPrice = itemPrice;
	}
	// ***DOUBLE GETTERS/SETTERS END***
	
	// ***INTEGER GETTERS/SETTERS START***
	// get quantity
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	// availableQuantity
	public Integer getAvailableQuantity() {
		return availableQuantity;
	}

	public void setAvailableQuantity(Integer availableQuantity) {
		this.availableQuantity = availableQuantity;
	}
	// ***INTEGER GETTERS/SETTERS END***
	


}
