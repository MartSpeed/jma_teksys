package com.example.jma_thymetut;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JmaThymetutApplicationTests {

	@Test
	void contextLoads() {
	}

}
