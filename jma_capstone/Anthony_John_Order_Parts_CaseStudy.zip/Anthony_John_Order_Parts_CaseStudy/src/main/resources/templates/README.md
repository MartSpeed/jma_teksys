```
<!-- aircraft model-->
<td><label for="input" >aircraft name</label></td>
<td><input th:field="*{aircraftName}" id="input" type="text" placeholder="name of aircraft"></td><br>
            <tr>
                <td><label for="input">aircraft model</label></td>
                <td><input type="text" placeholder="model of aircraft"></td><br>
            </tr>
            <!-- nose gear-->
            <tr>
                <td><label for="input">nose landing</label></td>
                <td><input type="text" placeholder="nose gear"></td><br>
            </tr>
             <!-- right main gear-->
             <tr>
                <td><label for="input">right main landing</label></td>
                <td><input type="text" placeholder="right main gear"></td><br>
            </tr>
             <!-- left main gear-->
             <tr>
                <td><label for="input">left main landing</label></td>
                <td><input type="text" placeholder="left main gear"></td><br>
            </tr>
            <!-- right wing-->
            <tr>
               <td><label for="input">right wing</label></td>
               <td><input type="text" placeholder="right wing"></td><br>
           </tr>
             <!-- left wing-->
             <tr>
                <td><label for="input">left wing</label></td>
                <td><input type="text" placeholder="left wing"></td><br>
            </tr>
             <!-- right elevator-->
             <tr>
                <td><label for="input">right elevator</label></td>
                <td><input type="text" placeholder="right elevator"></td><br>
            </tr>
             <!-- left elevator-->
             <tr>
                <td><label for="input">left elevator</label></td>
                <td><input type="text" placeholder="left elevator"></td><br>
            </tr>
             <!-- rudder-->
             <tr>
                <td><label for="input">rudder</label></td>
                <td><input type="text" placeholder="rudder"></td><br>
            </tr>
```