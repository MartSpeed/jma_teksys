package com.example.Anthony_John_Order_Parts_CaseStudy.service;

public interface AircraftPartInventoryService {

}
