##### 20220614
# REPOSITORY PACKAGE
The *Repository package* holds the **Java Interface** file for each **Entity/Data Access Object(DAO)**.
<br>
 The repository is responsible for the **CRUD operations** of your *entity fields* from the DAO.
<br>
The repository will *extend* the **JpaRepository** specifically for the use of the **Iterable functionality**.
<br>
> *NOTE*: 

---

# AIRCRAFT PARTS INVENTORY REPOSITORY
the aircraft repository is responsible for handling how the aircraft methods that supply the information for each objects method

