package com.example.Anthony_John_Order_Parts_CaseStudy.entity;

import javax.persistence.Column;

public class AircraftCartItems {

    // AIRCRAFT PART QUANTITY
    @Column
    private int quantity;
}
