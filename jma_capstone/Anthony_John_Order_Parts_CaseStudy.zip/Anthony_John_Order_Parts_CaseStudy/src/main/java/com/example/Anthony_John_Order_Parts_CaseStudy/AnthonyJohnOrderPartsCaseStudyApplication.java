package com.example.Anthony_John_Order_Parts_CaseStudy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnthonyJohnOrderPartsCaseStudyApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnthonyJohnOrderPartsCaseStudyApplication.class, args);
	}

}
