##### 20220611
# ENTITY PACKAGE
The entity package contains all of our Database Access Objects (DAO). These objects will contain all the information we want to
access in them using Lombok annotations.

# AIRCRAFT PARTS INVENTORY MODEL