package com.example.registrationlogintut;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistrationLoginTutApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistrationLoginTutApplication.class, args);
	}

}
