package com.example.jma_thymetut;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JmaThymetutApplication {

	public static void main(String[] args) {
		SpringApplication.run(JmaThymetutApplication.class, args);
	}

}
