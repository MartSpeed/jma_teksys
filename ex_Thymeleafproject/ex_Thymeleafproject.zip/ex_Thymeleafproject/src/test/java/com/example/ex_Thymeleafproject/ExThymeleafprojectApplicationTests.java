package com.example.ex_Thymeleafproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExThymeleafprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
