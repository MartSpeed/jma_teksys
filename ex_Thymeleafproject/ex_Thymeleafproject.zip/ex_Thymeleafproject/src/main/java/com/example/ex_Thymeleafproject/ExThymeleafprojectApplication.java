package com.example.ex_Thymeleafproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExThymeleafprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExThymeleafprojectApplication.class, args);
	}

}
