# **GOAL**

Your task is to create a basic School Management System where students can register for courses, and view the course assigned to them.

_Work-Flow_:

- [] Only students with the right credentials can log in. Otherwise, a message is displayed stating: “Wrong Credentials”.

- [] Valid students are able to see the courses they are registered for.
  Valid students are able to register for any course in the system as long as they are not already registered.

## Requirement 1 & 2

- [x] name the project SMS using [Spring Boot](https://start.spring.io/)
- [x] create database name SMS
- [x] change the mapping and password for hibernate.cfg.xml file
- [x] create jpa.entitymodels package
- [x] add studentEntity class
- [x] add courseEntity class
---
- ### STUDENT TABLE
> Every Model class must contain the following general two requirements:
> The first constructor takes no parameters and initializes every member to an initial value.
> The second constructor must initialize every private member with a parameter provided to the constructor.

  - [x] String sEmail (PK)
  - [x] String sName
  - [x] String sPass
  - [x] List sCourses
  - [x] create student getters/setters
  - [x] create student constructors with args
  - [x] create student initializer constructor
  - [x] create student ToString arg
```
package jpa.entitymodels;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.mapping.List;

@Entity
@Table(name="Student")
public class studentEntity {
	@Column(name = "email") // column name PK

	@Id
	private String sEmail;

	// FIELD NAMES
	private String sName, sPass;
	private List sCourses;

	// CONSTRUCTORS
	public studentEntity() {
	}

	public studentEntity(String sEmail, String sName, String sPass, List sCourses) {
		this.sEmail = sEmail;
		this.sName = sName;
		this.sPass = sPass;
		this.sCourses = sCourses;
	}

```
--- 
- ### COURSE TABLE
> Every Model class must contain the following general two requirements:
> The first constructor takes no parameters and initializes every member to an initial value.
> The second constructor must initialize every private member with a parameter provided to the constructor.
  - [x] Integer cId (PK)
  - [x] String cName
  - [x] String cInstructorName
  - [x] create course getters/setters
  - [x] create course constructors with args
  - [x] create course initializer constructor
  - [x] create course ToString arg
```
@Entity
@Table(name = "Course")
public class courseEntity {
	@Column(name = "courseId") // column name PK

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cId;

	// FIELDS
	private String cName, cInstructorsName;

	// CONSTRUCTORS
	public courseEntity() {
	}

	public courseEntity(int cId, String cName, String cInstructorsName) {
		this.cId = cId;
		this.cName = cName;
		this.cInstructorsName = cInstructorsName;
	}
```
---
## Requirement 3

### Student DAO
> This interface is going to have the following method declarations. Please include the proper method signature based on the **Service** table

- [x] create package jpa.dao
- [x] create class interface StudentDAO
  - [x] getAllStudents();
  - [x] getStudentByEmail();
  - [x] validateStudent();
  - [x] registerStudentToCourse();
  - [x] getStudentCourses();
```
  public interface StudentDAO {
	// INTERFACE THAT IMPLEMENTS THESE FOLLOWING CLASSES
	
	getAllStudents(); // all student information?
	
	getStudentByEmail(); // student email information?
	
	validateStudent(); // what does this validate?
	
	registerStudentToCourse(); // adding a student to a course
	
	getStudentCourses(); // get student courses
}
```
### CourseDAO

- [x] create class interface CourseDAO
  - [x] getAllCourses();
```
public interface CourseDAO {
	getAllCourses(); // one to many table?
}
```

## Requirement 4

### Services (Implementation)
- [x] create a package jpa.service
  - [] create class StudentService
    - [] StudentService class implements StudentDAO
  - [x] create class CourseService
    - [x] CourseService class implements CourseDAO

### StudentService Class Methods

- [] create getAllStudents() method
> reads the student table in your database and returns the data as a List<Student>
  - [] return List<Student>
  - [] takes no args

- [] create getStudentByEmail() method
> takes a students email as a String and parses the student list for a student with that email and returns a Student object
  - [] return Student
  - [] String sEmail arg

- [] create validateStudent() method
> takes two params: the first is the user email and second one is the password from the user input. return whether or not a student was found
  - [] boolean
  - [] String sEmail, String sPassword arg

- [] create registerStudentToCourse () method
> after successfull validation; this method takes a students email and a course id. it checks in the join table(StudentCourse) generated by JPA to find if a student with that email is currently attending a course with that ID. if the student IS NOT attending that course, register the student for that course; otherwise not
  - [] void method
  - [] String sEmail, int cId arg

- [] create getStudentCourses() method
> takes a student email as a param and would find all the courses a student registered for
  - [] return List<Courses>
  - [] String sEmail arg

- [] getAllScourses() method
> takes no params, returns every course in the table
  - [] return List<Courses>

