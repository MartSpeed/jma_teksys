package jpa.service;

public class CourseService {


}
