package com.example.ex_managementproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExManagementprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExManagementprojectApplication.class, args);
	}

}
