package com.example.ex_EmployeeManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExEmployeeManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExEmployeeManagerApplication.class, args);
	}

}
